package service;

public interface Entity {

    public Object createObject();
}
