package utils;

public enum Scenes {
    START_MENU,
    LOGIN,
    POST,
    REGISTER1,
    REGISTER2,
    HOMEPAGE,
    ADOPTION,
    PUT_IN_ADOPTION,
    FAVORITES,
    RESULTS;


}
